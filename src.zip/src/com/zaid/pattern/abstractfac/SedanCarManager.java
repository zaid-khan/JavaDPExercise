package com.zaid.pattern.abstractfac;

public class SedanCarManager extends CarManager{

	@Override
	public Gear createGear() {
		return new SedanCarGear();
	}

	@Override
	public Break createBreak() {
		return new SedanCarBreak();
	}

}
