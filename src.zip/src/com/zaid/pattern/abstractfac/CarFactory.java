package com.zaid.pattern.abstractfac;

public class CarFactory {

	public static CarManager createCarManager(char type) {
		if (type == 'L') {
			return new LuxuryCarManager();
		}
		if (type == 'S') {
			return new SedanCarManager();
		}
		return null;
	}
}
