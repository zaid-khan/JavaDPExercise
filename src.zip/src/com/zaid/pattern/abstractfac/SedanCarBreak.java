package com.zaid.pattern.abstractfac;

public class SedanCarBreak extends Break{

	@Override
	public void returnPart() {
		super.returnPart();
		System.out.println("Returning Sedan Car Break");
	}

	
}
