package com.zaid.pattern.abstractfac;

public abstract class Gear extends Part {
	
	@Override
	public void returnPart() {
		System.out.println("Selecting Part : Gear!");
		
	}

}
