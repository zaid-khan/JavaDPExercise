package com.zaid.pattern.abstractfac;

public class LuxuryCarManager extends CarManager{

	@Override
	public Gear createGear() {
		return new LuxuryCarGear();
	}

	@Override
	public Break createBreak() {
		return new LuxuryCarBreak();
	}

}
