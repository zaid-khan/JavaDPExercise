package com.zaid.pattern.abstractfac;

public class LuxuryCarGear extends Gear{

	@Override
	public void returnPart() {
		super.returnPart();
		System.out.println("Returning Luxury Car Gear");
	}

	
}
