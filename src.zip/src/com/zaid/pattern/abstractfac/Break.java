package com.zaid.pattern.abstractfac;

public abstract class Break extends Part {

	@Override
	public void returnPart() {
		System.out.println("Selecting Part : Break!");
		
	}
}
