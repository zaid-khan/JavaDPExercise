package com.zaid.pattern.abstractfac;

public class SedanCarGear extends Gear{

	@Override
	public void returnPart() {
		super.returnPart();
		System.out.println("Returning Sedan Car Gear");
	}

}
