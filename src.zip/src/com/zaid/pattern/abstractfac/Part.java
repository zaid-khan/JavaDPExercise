package com.zaid.pattern.abstractfac;

public abstract class Part {

	public abstract void returnPart();

}
