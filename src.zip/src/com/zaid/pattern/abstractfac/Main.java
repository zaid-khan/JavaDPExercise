package com.zaid.pattern.abstractfac;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CarManager carManager = CarFactory.createCarManager('L');
		Gear gear = carManager.createGear();
		Break break_ = carManager.createBreak();
		gear.returnPart();
		break_.returnPart();
	}

}
