package com.zaid.pattern.abstractfac;

public class LuxuryCarBreak extends Break {

	@Override
	public void returnPart() {
		super.returnPart();
		System.out.println("Returning Luxury Car Break");
	}
	
	

}
