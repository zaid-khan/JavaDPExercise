package com.zaid.pattern.abstractfac;

public abstract class CarManager {

	public abstract Gear createGear();
	public abstract Break createBreak();
	
}
