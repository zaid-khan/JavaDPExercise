package com.zaid.pattern.visitor;

import java.util.List;

public class TotalSalaryVisitor implements Visitor {

	@Override
	public void visit(List<Employee> employees) {
		
		double totalSalary = 0;
		
		for(Employee employee : employees)
		{
			totalSalary += employee.getSalary();
		}
		
		System.out.println("Total Salary given to all Employees : Rs. " + totalSalary);
		
	}
	
	

}
