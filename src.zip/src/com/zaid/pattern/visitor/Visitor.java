package com.zaid.pattern.visitor;


import java.util.List;

public interface Visitor {

	public void visit(List<Employee> e);
	
}	