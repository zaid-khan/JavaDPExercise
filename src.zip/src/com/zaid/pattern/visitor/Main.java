package com.zaid.pattern.visitor;

public class Main {

	public static void main(String[] args) {
		
		Organization deutscheBank = new Organization();
		
		deutscheBank.addEmployee(new Employee("Zaid", 3533779, 5000, "Analyst", "Technology"));
		deutscheBank.addEmployee(new Employee("Raju", 3233779, 3000, "Technician", "Technology"));
		deutscheBank.addEmployee(new Employee("Fahd", 3133779, 7000, "Sr. Analyst", "Technology"));
		deutscheBank.addEmployee(new Employee("Monty", 3633779, 10000, "V.P.", "Technology"));
		
		TotalSalaryVisitor totalSalaryVisitor = new TotalSalaryVisitor();
		AverageSalaryVisitor averageSalaryVisitor = new AverageSalaryVisitor();
		
		
		deutscheBank.accept(totalSalaryVisitor);
		deutscheBank.accept(averageSalaryVisitor);
		
		
	}

}
