package com.zaid.pattern.visitor;

import java.util.List;

public class AverageSalaryVisitor implements Visitor {

	@Override
	public void visit(List<Employee> employees) {
		
		double totalSalary = 0;
		
		for(Employee employee : employees)
		{
			totalSalary += employee.getSalary();
		}
		
		System.out.println("Average Salary of an Employee : Rs. " + (totalSalary / employees.size()));
		
	}
	
	

}
