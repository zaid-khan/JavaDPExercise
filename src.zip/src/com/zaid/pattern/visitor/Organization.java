package com.zaid.pattern.visitor;

import java.util.ArrayList;
import java.util.List;

public class Organization {

	List<Employee> employees = new ArrayList<>();

	public void addEmployee(Employee employee) {
		employees.add(employee);
	}

	public void removeEmployee(Employee employee) {
		employees.remove(employee);
	}

	public Employee getWorker(int index) {
		return employees.get(index);
	}

	public List<Employee> getAll() {
		return employees;
	}
	
	public void accept(Visitor visitor) {
		visitor.visit(this.employees);
	}

}
