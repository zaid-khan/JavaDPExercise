package com.zaid.solid.liskov;


class GeometricCalculation
{
	public static double getAreaOfShape(Shape s)
	{
		return s.calculateArea();		
	}
}


public class Main {

	public static void main(String[] args) {
	
		double areaRectangle = GeometricCalculation.getAreaOfShape(new Rectangle(5, 10));
		System.out.println("Area of Rectangle : " + areaRectangle);
		
		double areaTriangle = GeometricCalculation.getAreaOfShape(new Triangle(10, 15));
		System.out.println("Area of Triangle : " + areaTriangle);
		
		double areaCircle = GeometricCalculation.getAreaOfShape(new Circle(10));
		System.out.println("Area of Circle : " + areaCircle);
		
	}

}
