package com.zaid.solid.liskov;

interface Shape {
	public abstract double calculateArea();
}
