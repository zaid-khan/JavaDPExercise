import React from 'react';
import './styles.css';

class CricketCommunity extends React.Component {

    constructor() {
        super();
        this.state = {
            boardname: 'BCCI',
            estdate: '1947',
            teamname: 'Indian Cricket Team',
            winner: "'83, '11"
        }
    }

    render() {
        return (
            <div className='beautify'>
                <table>
                    <thead>
                        <tr>
                            <th colSpan="2" className="underline">
                                Cricket Community Information
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Board Name</td>
                            <td>{this.state.boardname}</td>
                        </tr>
                        <tr>
                            <td>Est. Date</td>
                            <td>{this.state.estdate}</td>
                        </tr>
                        <tr>
                            <td>Team Name</td>
                            <td>{this.state.teamname}</td>
                        </tr>
                        <tr>
                            <td>Winners</td>
                            <td>{this.state.winner}</td>
                        </tr>
                    </tbody>
                </table>
                
            </div>
        )
    }
}

export default CricketCommunity;