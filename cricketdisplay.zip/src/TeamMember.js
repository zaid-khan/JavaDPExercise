import React from 'react';
import './styles.css';

class TeamMember extends React.Component {

    constructor() {
        super();
        this.state = {
            captain: 'Kohli',
            batsman: 'Rahul',
            bowler: 'Bumra'
        }
    }

    render() {
        return (
            <div className='beautify'>
                <table>
                    <thead>
                        <tr>
                            <th colSpan="2" className="underline">
                                Team Information
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Captain Name</td>
                            <td>{this.state.captain}</td>
                        </tr>
                        <tr>
                            <td>Batsman Name</td>
                            <td>{this.state.batsman}</td>
                        </tr>
                        <tr>
                            <td>Bowler Name</td>
                            <td>{this.state.bowler}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        )
    }
}

export default TeamMember;