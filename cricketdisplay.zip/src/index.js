import React from 'react';
import ReactDOM from 'react-dom';
import CricketCommunity from './CricketCommunity';
import TeamMember from './TeamMember';


ReactDOM.render(<CricketCommunity />,document.getElementById('cricket-community'));
ReactDOM.render(<TeamMember />,document.getElementById('team-member'));